package net.mzouabi.ng2.server.repository;

public interface PersonRepositoryCustom {


}
