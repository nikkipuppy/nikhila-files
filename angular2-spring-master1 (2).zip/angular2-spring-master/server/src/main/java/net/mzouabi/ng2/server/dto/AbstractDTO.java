package net.mzouabi.ng2.server.dto;

/**
 * Created by mouradzouabi on 05/03/16.
 */
public class AbstractDTO {

    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
