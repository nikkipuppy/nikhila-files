export interface Person {

    id : number;
    
}
